var datos = new Vue ({
    el:'#datos' ,
    data: {
        usuarios:[]
    },

    methods: {
        agregarUsuario: function(username, contrasenya) {
            usuarios.push({usuario: username, contraseña: contrasenya});
        }
    }
})