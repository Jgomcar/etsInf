var app = new Vue({
    el:'#app',
    data: {
        message: 'Hola Mundo!'
    }
})

var app2 = new Vue({
    el: '#app2' ,
    data: {
        message:'Usted cargó esta página el ' + new Date().toLocaleString
    }
})