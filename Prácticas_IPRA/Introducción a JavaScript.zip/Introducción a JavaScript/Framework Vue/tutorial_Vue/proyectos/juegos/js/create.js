import Toasted from 'vue-toasted';

const SERVER_URL = "https://apirestflaskpythonsqlite3.parzibyte.repl.co"
Vue.use(Toasted);
new Vue({
    el: "#app",
    data: () => ({
        game: {
            name: "",
            price: "",
            rate: "",
        },
    }),
    methods: {
        async save() {
            if (!this.game.name) {
                return this.$toasted.show("Please write name", {
                    position: "top-left",
                    duration: 1000,
                });
            }

            if (!this.game.price) {
                return this.$toasted.show("Please write price", {
                    position: "top-left",
                    duration: 1000,
                });
            }
            if (!this.game.rate) {
                return this.$toasted.show("Please write rate", {
                    position: "top-left",
                    duration: 1000,
                });
            }
            
            localStorage.name = this.game.name;
            localStorage.price = this.game.price;
            localStorage.rate = this.game.rate;
            console.log("Juego guardado en el almacenamiento")

            }
        }
    }
});