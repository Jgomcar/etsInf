var listaRara = new Vue({
    el:"#listaRara",
    data: {
        lista: "<li>Coche</li><li>Moto</li><li>Avión</li>",
    }
})

var cabecera = new Vue ({
    el:'#cabecera',
    data:{
        saludo : "Hola de nuevo ",
        nombre: "",
        visible: false,
        textoBoton: "Soy un boton",
        url: "https://www.google.com/webhp?hl=es&sa=X&ved=0ahUKEwjn5P-W663yAhWJsBQKHVkuD18QPAgI"
    },
    created: function() {
         let nombre = "";
        while (nombre == "") {
            nombre = prompt("¿Quién eres?");
        }
        this.nombre = nombre;
    },

    mounted: function() {
        alert("Ya se ha montado");
    },

    beforeUpdate: function() {
        alert("Se va a actualizar");
    },

    updated: function() {
        alert("Ya se ha actualizado")
    }, 

    computed:{

    },
    methods: {
        cambioDeNombre: function() {
            cambiarNombre();
        }
    }
    
})

function cambiarNombre() {
    let nuevoNombre = "";
    while(nuevoNombre == ""){
        nuevoNombre = prompt("¿Cúal es tu verdadero nombre?");
    }
    cabecera.nombre = nuevoNombre;
    cabecera.visible = true;
}

function cambiarTexto() {
    cabecera.textoBoton = "Texto cambiado";
}



Vue.component('button-counter', {
    data: function () {
        return {
            count: 0
        }
    },
    template:'<button @click="count++">Me ha pulsado {{ count }} veces.</button>'
})
new Vue({ el:"#components-demo"})