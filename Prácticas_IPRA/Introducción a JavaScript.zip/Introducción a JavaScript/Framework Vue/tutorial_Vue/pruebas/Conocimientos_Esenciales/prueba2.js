// Las props son atributos personalizados que 
// usted puede registrar en un componente.


Vue.component('blog-post', {
    // formato camelCase en JavaScript
    props: ['postTitle'],
    template: '<h3>{{ postTitle }}</h3>'
  })

