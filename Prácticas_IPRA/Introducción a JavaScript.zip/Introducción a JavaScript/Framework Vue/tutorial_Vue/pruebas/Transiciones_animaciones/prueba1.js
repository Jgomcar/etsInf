new Vue ({
    el: '#demo',
    data: {
        show: true
    }
})

new Vue({
    el: '#example-1',
    data: {
      show: true
    }
  })
  