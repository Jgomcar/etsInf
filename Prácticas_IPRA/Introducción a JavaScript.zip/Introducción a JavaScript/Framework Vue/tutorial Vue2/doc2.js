const app = new Vue({
    el: '#app',
    data: {
        fondo: 'bg-warning',
        color: false
    },
    methods: {

    }
})