Vue.component('saludo', {
    template: //html
    ` 
    <div> <!-- tiene que quedar dentro de un contenedor como un div-->
        <h1>{{saludo}}</h1>
        <h3>texto</h3>
    </div>
    `,
    data() {
        return {
            saludo: 'Saludos'
        }
    }
})
