Vue.component('padre', {
    template: //html
    ` 
    <div class="py-5 bg-dark text-white"> <!-- tiene que quedar dentro de un contenedor como un div-->
        <h2>Componente Padre: {{ numeroPadre }}</h2>
        <button class="btn btn-danger" @click="numeroPadre++">+</button>
        {{nombrePadre}}
        <hijo :numero="numeroPadre" @nombreHijo="nombrePadre = $event"></hijo>
    </div>
    `,
    data() {
        return{
            numeroPadre: 0,
            nombrePadre: '',
        }
    }
})
