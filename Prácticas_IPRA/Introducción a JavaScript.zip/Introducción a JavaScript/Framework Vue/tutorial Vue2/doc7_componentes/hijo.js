Vue.component('hijo', {
    template: //html
    `
    <div class="py-5 bg-success">
        <h4>Componente hijo: {{numero}} </h4>
        <h5> Nombre: {{nombre}}</h5>
    </div>
    `,
    props:['numero'],
    data(){
        return{
            nombre: 'Olga'
        }
    },
    mounted() {
        this.$emit('nombreHijo', this.nombre );
    }
})
