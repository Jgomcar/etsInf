function insertarNombre(evt) {
    /**Para que no recargue la página */
    evt.preventDefault();

    let nombre = document.getElementById("nombre").value;
    if (nombre !== "") {
        let opcion = "<li> " + nombre + "</li>";

        let lista = document.getElementById("lista_nombres");
        /**innerHTML sirve para escribir en el html */
        lista.innerHTML += opcion;
        alert ("Nombre insertado")
    } else {
        alert ("Nombre no puede ser vacío")
    }

}