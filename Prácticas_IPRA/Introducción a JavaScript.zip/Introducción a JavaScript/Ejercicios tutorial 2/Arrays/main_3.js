function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min))+ min;
}

let array = [];

for (let i = 1; i <= 10; i++){
    array.push(getRandomInt(1, 100));
}
/**Si hacemos una copia de esta forma se copia hasta la referencia */
let array2 = array;

array2.push(5);

let array3 = array.slice()

array3.push(10)

console.log("Array 1:")
console.log(array);

console.log("Array 2:")
console.log(array2);

console.log("Array 3:")
console.log(array3);