let array = [];

for (let i = 1; i <= 10; i++){
    array.push(i);
}

console.log(array);