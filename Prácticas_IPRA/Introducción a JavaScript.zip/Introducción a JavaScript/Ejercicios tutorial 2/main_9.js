function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function ordenar(){
    let array = [];

    for (let i = 0; i < 10; i++){
        array.push(getRandomInt(1, 100));
    }
    console.log("Array sin ordenar");
    console.log(array);
    /**Se le pasa esa funcion porque si no lo ordena solo con las primeras cifras */
    array.sort(function (a,b) {return a - b});
    console.log("Array ordenado");
    console.log(array)

    let ul = document.createElement("ul");

    for (let i = 0; i <  array.length; i++) {
        const element = array[i];
        let li = document.createElement("li");
        let textLi =document.createTextNode(element);
        li.appendChild(textLi);
        ul.appendChild(li);
    }

    let valores = document.getElementById("valores");;
    valores.appendChild(ul);

}
/**Cuando yo cargue la página se ejecutará ese método */
window.onload = ordenar;