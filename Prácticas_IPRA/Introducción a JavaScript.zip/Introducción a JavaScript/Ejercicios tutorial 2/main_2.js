function sumaNumeros() {
    let num1=5;
    let num2=10;

    document.write(num1 + num2);
}