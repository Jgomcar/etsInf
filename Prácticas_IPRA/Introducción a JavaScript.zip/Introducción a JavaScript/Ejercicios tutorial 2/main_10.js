function cargarCombo() {

    let dateInit = new Date();
    dateInit.setHours(0);
    dateInit.setMinutes(0);
    dateInit.setSeconds(0);
    dateInit.setUTCMilliseconds(0);

    let dateFin = new Date();
    dateFin.setHours(23);
    dateFin.setMinutes(59);
    dateFin.setSeconds(0);
    dateFin.setUTCMilliseconds(0);

    let minutes = 20;

    let ms = minutes * 60 * 1000; /**Pasar los minutos a milisegundos */

    let combo = document.getElementById("hour");

    while(dateInit.getTime() < dateFin.getTime()) {

        let option = document.createElement("option");
        option.setAttribute("value", dateInit);

        console.log(dateInit.toTimeString());

        let time = dateInit.toTimeString().split(' ')[0];

        console.log(time);

        time = time.split(':');
        time = time[0] + ":" + time[1]; 

        let text = document.createTextNode(time);
        option.appendChild(text)

        combo.appendChild(option);

        dateInit.setTime(dateInit.getTime() + ms);

    }

}

window.onload = cargarCombo