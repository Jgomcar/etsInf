function mayorNum(){
    let num1 = document.getElementById("num1").value;
    let num2 = document.getElementById("num2").value;

    if (num1 && num2) {/**Comprobación de que existen */
        if(num1 > num2) {
            alert("El mayor es: " + num1);
        } else {
            if (num1 < num2) {
                alert("El mayor es: " + num2);
            } else {
                alert("Los números son iguales")
            }
        }
    } else {
        alert("Faltan números por introducir")
    }
}
