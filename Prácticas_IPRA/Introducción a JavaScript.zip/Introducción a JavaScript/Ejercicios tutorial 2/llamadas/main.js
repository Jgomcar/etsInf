function cargarJSON() {
    let llamada = XMLHttpRequest()

    let url = "datos.json";

    /**Cuando la informacion venga... */
    llamada.onreadystatechange() = function() {
        if (this.readyState == 4 && this.status == 200){
            
            console.log("recibida la informacion del fichero");
            let datos = JSON.parse(this.responseText);

            console.log(datos);

        }
    }
    console.log("Se envía la petición");
    llamada.open("GET", url, true);
    llamada.send();
}

window.load = cargarJSON;