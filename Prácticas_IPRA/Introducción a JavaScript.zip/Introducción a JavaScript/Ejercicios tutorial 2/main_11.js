fechas = [];

function anyadirFecha(){
    const form = document.forms["formFechas"];
    const fecha = form.fecha.value;
    if (fecha !== ""){
        fechas.push(new Date(fecha));
        fechas.sort(function (a,b) {
            return a-b;
        })
        alert("la fecha se ha añadido.")
    }

}

function mostrarResultados() {

    let fechaMenor = fechas[0];
    let fechaMayor = fechas[fechas.length - 1];
    let numFechas = fechas.length;

    let etiqFechaMenor = document.getElementById("fechaMenor");
    let etiqFechaMayor = document.getElementById("fechaMayor");
    let etiqNumFechas = document.getElementById("numFechas");

    etiqFechaMenor.innerHTML = fechaMenor ? fechaMenor:"No hay fecha";
    etiqFechaMayor.innerHTML = fechaMayor ? fechaMayor:"No hay fecha";
    etiqNumFechas.innerHTML = numFechas;

}