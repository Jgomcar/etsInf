let num1 = prompt("dame el primer número");
let num2 = prompt("dame el segundo número");

let aleatorio = generarAleatorio(num1, num2);
alert(aleatorio);

if (esNumero(num1)){
    alert("Es un número");
} else {
    alert("No es un número");
}