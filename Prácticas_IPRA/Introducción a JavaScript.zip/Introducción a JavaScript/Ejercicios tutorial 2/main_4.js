function muestraOpcion(){
    /* Cogemos todos los elementos con ese nombre */
    var opciones = document.getElementsByName("eleccion");
    /*Devuelve una array de elementos */
    console.log(opciones);

    for(let i = 0; i < opciones.length; i++) {/** Recorremos el array de elemetos */
        
        /** Si el elemento iésimo está seleccionado, saltar alerta con el valor de ese elemento */
        if(opciones[i].checked){
            alert(opciones[i].value);
        }
    }
}