/**Mostrar en HTML un reloj que se acutalice cada segundo
 * Esta hoja no está aplicada a ningún HTML.
 */


function muestraReloj() {
    let fechaHora = new Date();
    let horas = fechaHora.getHours();
    let minutos = fechaHora.getMinutes();
    let segundos = fechaHora.getSeconds()

    if (horas < 10) { horas = "0" + horas;}
    if (minutos < 10) { minutos = "0" + minutos;}
    if (segundos < 10) { segundos = "0" + segundos;}

    document.getElementById("reloj").innerHTML = horas + ':' + minutos + ':' +segundos
}

/**Para que se repita cada segundo */
window.onload = function() {
    setInterval(muestraReloj, 1000);
}

/**Con estos conceptos se pueden construir contadores o cuentas atrás */