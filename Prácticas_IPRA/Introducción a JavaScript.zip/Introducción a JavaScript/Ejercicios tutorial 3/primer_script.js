function holaMundo(){
    alert("¡Hola Mundo!");
    alert("Soy el primer script");
    /**Ejercicio 2 */
    let mensaje = alert("Hola Mundo!\n Aprendiendo a poner \'comillas simples\' y \"comillas dobles\" ");

    /**Ejercicio 3 Arrays */
    let meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio"];/**No voy a ponerlos todos */
    mensaje ="";
    for (mes in meses){
        mensaje +=meses[mes] + " "
    }
    alert(mensaje);

}

function parOImpar(){
    let número = prompt("Introduce un número entero");
    let res = even_odd(número);
    alert("Ese número es: " + res);

}

function even_odd(número){
    if (número % 2 == 0) {
        return "Par";
    } else return "Impar";
}


window.onload(holaMundo());