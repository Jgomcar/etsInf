/** Se le atribuye al atributo "onsubmit" de un botón o input.
 * Se puede derivar a una función: onsubmit="validacion()"
 * Debe devolver True o False.
 * Usado normalmente en formularios.
 */
/**
 * Esta es una hoja de funciones general, no aplicada a ningún HTML
 */

function validacion(){
    /**Para validar un texto obligatorio */
    let valor =document.getElementById("nombre").value;
    if ( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) { /**Mientras sea null, o con longitud 0 o todo espacios en blanco*/
        return false
    }

    /**Para un campo de texto con solo valores numéricos */
    let valor = document.getElementById("edad").value;
    if ( isNaN(valor) ){ /** If Not a Number */
        return false;
    }

    /**Validar que se ha seleccionado una opción de la lista */
    let indice = document.getElementById("opciones").selectedIndex;
    if ( indice == null || indice == 0 ) {
        return false;
    }

    /**Validar una dircción de email 
     * Esta expresión regular comprueba que la dirección de correo parezca válida.
     * Ya que no se comprueba si se trata de una dirección real y opertiva.
     * Esta expresión no valida todos los formatos pero si la mayoría.
    */
    let valor = document.getElementById("email").value;
    if ( !(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)/.test(valor)) ) {
        return false
    }

    /**Validar una fecha */

    let anyo = document.getElementById("año").value;
    let mes = document.getElementById("mes").value;
    let dia = document.getElementById("dia").value;

    valor =new DataCue(anyo, mes, dia);

    if (!isNaN(valor)){
        return false;
    }

    /** Validar un número de DNI */
    valor = document.getElementById("dni").value;
    let letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];

    if ( !(/^\d{8}[A-Z]$/.test(valor)) ) { /**Comprueba que esté formado por 8 número y una letra detrás */
        return false; 
    }
    
    if(valor.charAt(8) != letras[(valor.substring(0,8)) % 23 ]) { /**Comprueba que sea la letra adecuada aplicando el cálculo de la letra del DNI */
        return false;
    }

    /**Validar un número de teléfono */
    valor = document.getElementById("número_tlf").value;
    if ( !(/^\d{9}$/.test(valor)) ) {
        return false;
    }

    /**Validar que un check box ha sido seleccionado */
    let element = document.getElementById("campo");
    if ( !element.checked ) {
        return false;
    }

    /**Validar todos los checkboxes, utilizamos un bucle */
    let formulario = document.getElementById("formulario"); /**Aunque podemos utilizar document.forms["formulario"] poniendo el "name" del formulario = "formulario"*/
    for ( let i = 0; i<formulario.nextElementSibling.length; i++ ) {
        let element = formulario.elements[i];
        if ( element.type == "checkbox" ) {
            if ( !element.checked ) {
                return false;
            }
        }
    }

    /**Validar que un radiobutton ha sido seleccionado
     * En este caso cuando encuentra el primero se sale del bucle
    */
    let opciones = document.getElementsByName("opciones");

    let seleccionado = false
    for (let i = 0; i<opciones.length; i ++) {
        if (opciones[i].checked) {
            seleccionado = true;
            break;
        }
    }
    return seleccionado;
}