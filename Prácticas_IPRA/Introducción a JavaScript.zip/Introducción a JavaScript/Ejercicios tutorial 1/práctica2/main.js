
function iniciarSesion(event) {
    /*event.preventDefault(); /**Evento que no recarga la página */
    event.preventDefault();

    resasturar_mensajes_error();
    let form = document.forms["formulario_inicio"];

    let nombre = form.nombre.value;
    let apellido = form.apellido.value;
    let edad = form.edad.value

    if ( nombre == null || nombre.length == 0 || /^\s+$/.test(nombre) ) { 
        let texto = document.getElementById("error_nombre");
        texto.innerHTML = "Nombre introducido no válido."
        return false
    }

    if ( apellido == null || apellido.length == 0 || /^\s+$/.test(apellido) ) { 
        let texto = document.getElementById("error_apellido");
        texto.innerHTML = "Apellido introducido no válido."
        return false
    }

    if ( isNaN (edad) || edad == "") {
        let texto = document.getElementById("error_edad");
        texto.innerHTML = "Edad introducida no válida."
        return false
    }
    
    alert("Nombre: " + nombre + "\n" +
    "Apellido: " + apellido + "\n" +
    "Edad: " + edad + "."
    )
    document.getElementById("btn_inicio").disabled(true);
    document.getElementById("btn_inicio").value("Iniciando");

    return true

}

function  resasturar_mensajes_error() {
    let textosError = document.getElementsByName("texto_error");
    for (let i = 0; i < textosError.length; i++) {
        textosError[i].innerHTML = " ";
    }
}

function muestraReloj() {
    let fechaHora = new Date();
    let horas = fechaHora.getHours();
    let minutos = fechaHora.getMinutes();
    let segundos = fechaHora.getSeconds()

    if (horas < 10) { horas = "0" + horas;}
    if (minutos < 10) { minutos = "0" + minutos;}
    if (segundos < 10) { segundos = "0" + segundos;}

    document.getElementById("reloj").innerHTML = horas + ':' + minutos + ':' +segundos
}

/**Para que se repita cada segundo */
window.onload = function() {
    setInterval(muestraReloj, 1000);
}