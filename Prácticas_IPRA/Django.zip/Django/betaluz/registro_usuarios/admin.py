from django.contrib import admin

# Register your models here.
from .models import  Instalación, ParqueSolar

admin.site.register(Instalación)
admin.site.register(ParqueSolar)