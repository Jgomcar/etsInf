from django.db import models
from django.contrib.auth.models import User
from django.db.models.fields import IntegerField


# Create your models here.

class ParqueSolar(models.Model):
    nombre = models.CharField(max_length = 100)
    ubicación = models.IntegerField(default = None)
    potencia_total = models.FloatField(default = 0)

    class Meta:
        ordering = ('nombre',)

class Instalación(models.Model):
    usuario_jefe = models.ForeignKey(User, on_delete = models.CASCADE)
    parque_solar = models.ForeignKey(ParqueSolar, on_delete = models.CASCADE)
    referencia = models.IntegerField(default = "0")
    potencia = models.FloatField(default = 0)
    encendida = models.BooleanField(default = False)
    
    class Meta:
        ordering = ('usuario_jefe',)

    def __str__(self):
        return """
           Parque Solar = {}\n
            Referencia = {}\n
            Potencia = {}\n
            Funcionamiento = {}\n
        """.format(self.parque_solar, self.referencia, self.potencia, self._funcionamiento())

    def _funcionamiento(self):
        funcionando = self.encendida
        if funcionando:
            return "Funcionando"
        else:
            return "Apagada"

    def lista_datos_instalación(self):
        return [self.usuario_jefe, self.parque_solar, self.referencia, self.potencia, self._funcionamiento() ]