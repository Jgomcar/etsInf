from django.urls import path
from django.urls.resolvers import URLPattern
from . import views

app_name = "registro_usuarios"
urlpatterns = [
    path('<str:next_window>registro/', views.registro, name = 'registro'),
    path('registro_parqueSolar/', views.registro_parqueSolar, name = 'registro_parqueSolar'),
    path('registro_instalacion/', views.registro_instalacion, name = 'registro_instalacion'),
    path('identificacion/', views.identificacion, name = 'identificacion'),
    path('<int:referencia_instalacion>/<str:username>/<str:accion>/pagina_principal/', views.pagina_principal, name = 'pagina_principal'),
    path('<int:referencia_instalacion>/edición_instalación', views.instalación_edit, name="edición_instalación"),
    path('<str:username>/editar_usuarios', views.usuario_edit, name="editar_usuarios"),
]