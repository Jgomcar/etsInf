from django.shortcuts import get_object_or_404
from .models import Instalación, ParqueSolar, User


def obtener_instalaciones_usuario(usuario):
    return Instalación.objects.filter(usuario_jefe = usuario)

def prueba(lista_intalaciones):
    res = []
    for instalacion in lista_intalaciones:
        res += [instalacion.lista_datos_instalación()]

    return res

def modificar_instalación(instalacion, encargado, parque_solar, referencia, potencia):
    encargado = get_object_or_404(User, username = encargado)
    parque_solar = get_object_or_404(ParqueSolar, nombre = parque_solar)
    instalacion.usuario_jefe = encargado
    instalacion.parque_solar = parque_solar
    instalacion.referencia = referencia
    instalacion.potencia = potencia
    instalacion.save()

def modificar_usuario(usuario, username, email, password):
    usuario.username = username
    usuario.email = email
    usuario.password = password
    usuario.save()


def borrar_usuario(username):
    usuario = User.objects.get(username = username)
    usuario.delete()