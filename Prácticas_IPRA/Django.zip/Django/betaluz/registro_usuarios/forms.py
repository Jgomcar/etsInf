from django import forms
from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from django.contrib.auth.models import User

class RegistroUsuarioForm(UserCreationForm):
    username = forms.CharField(label="Nombre Usuario")
    email = forms.EmailField(label="Email")
    password1 = forms.CharField(label="Contraseña", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Repetir Contraseña", widget=forms.PasswordInput)

class IdentificacionForm(forms.Form):
    Nombre_Usuario = forms.CharField(label = "Nombre de Usuario",max_length= 100)
    Contraseña = forms.CharField(label="Contraseña", widget=forms.PasswordInput)

class AnyadirInstalacionForm(forms.Form):
    Encargado = forms.CharField(label= "Encargado:")
    Parque_Solar = forms.CharField(label= "Parque Solar:")
    Referencia = forms.IntegerField(label= "Referencia:")
    Potencia =  forms.FloatField(label = "Potencia:")

class AnyadirParqueSolarForm(forms.Form):
    Nombre = forms.CharField(label = "Nombre",max_length = 100)
    Ubicación = forms.IntegerField(label = "Ubicación")
    Potencia_total = forms.FloatField(label = "Potencia Total")

class EditarUsuario(forms.Form):
    username = forms.CharField(label="Nombre Usuario")
    email = forms.EmailField(label="Email")
    password = forms.CharField(label="Contraseña")