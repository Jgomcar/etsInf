from django import forms
from django.shortcuts import get_object_or_404, redirect, render
from .forms import AnyadirInstalacionForm, AnyadirParqueSolarForm, EditarUsuario, RegistroUsuarioForm, IdentificacionForm
from django.contrib.auth import  login, authenticate
from django.contrib.auth.models import User
from django.contrib.auth.models import Permission
from .models import *
from .código_complementario import borrar_usuario, modificar_usuario, obtener_instalaciones_usuario, modificar_instalación

# Create your views here.

def registro_parqueSolar(request):
    if request.method == 'POST':
        form_nuevo_parqueSolar = AnyadirParqueSolarForm(request.POST)
        if form_nuevo_parqueSolar.is_valid():
            datos_parqueSolar = form_nuevo_parqueSolar.cleaned_data
            nuevo_parqueSolar = ParqueSolar.objects.create(nombre = datos_parqueSolar['Nombre'], ubicación = datos_parqueSolar['Ubicación'],
            potencia_total = datos_parqueSolar['Potencia_total'])
            nuevo_parqueSolar.save()
            return redirect('registro_usuarios:pagina_principal', 0, "usuario", "nada")
    else:
        form_nuevo_parqueSolar = AnyadirParqueSolarForm()
    return render(request, "formulario.html",{ "título":"Nuevo Parque Solar" ,"form":form_nuevo_parqueSolar, "mensaje_boton":"Registrar parque solar"})


def registro_instalacion(request):
    if request.method == 'POST':
        form_nueva_instalacion = AnyadirInstalacionForm(request.POST)
        if form_nueva_instalacion.is_valid():
            datos_instalacion = form_nueva_instalacion.cleaned_data
            try:
                encargado = get_object_or_404(User, username = datos_instalacion['Encargado'])
                parque_solar = get_object_or_404(ParqueSolar, nombre = datos_instalacion['Parque_Solar'])
                nueva_instalacion = Instalación.objects.create(usuario_jefe = encargado, parque_solar = parque_solar, referencia = datos_instalacion['Referencia'], 
                potencia = datos_instalacion['Potencia'], encendida = False)
                nueva_instalacion.save()
                return redirect('registro_usuarios:pagina_principal', 0, "usuario", "nada")
            except:
                print("Datos incorrectos")
    else:
        form_nueva_instalacion = AnyadirInstalacionForm()
    return render(request, "formulario.html",{ "título":"Nueva Instalación" ,"form":form_nueva_instalacion, "mensaje_boton":"Registrar instalación"})

def registro(request, next_window):
    if request.method == 'POST':
        formulario_registro = RegistroUsuarioForm(request.POST)
        if formulario_registro.is_valid():
            datos_usuario = formulario_registro.cleaned_data
            usuario_nuevo = User.objects.create_user(username = datos_usuario['username'] ,email = datos_usuario['email'], password = datos_usuario['password1'])
            usuario_nuevo.save()
            print("\nUSUARIO REGISTRADO\n")
            if next_window == 'pagina_principal':
                return redirect('registro_usuarios:pagina_principal', 0, "usuario", "nada")
            else:
                return redirect('registro_usuarios:identificacion')

    else:
        formulario_registro = RegistroUsuarioForm()
    
    return render(request, "formulario.html",{ "título":"Registro" ,"form":formulario_registro, "mensaje_boton":"Registrar usuario"})

def identificacion(request):
    if request.method == 'POST':
        formulario_registro = IdentificacionForm(request.POST)
        if formulario_registro.is_valid():
            datos_usuario = formulario_registro.cleaned_data
            try:
                usuario = authenticate(username = datos_usuario['Nombre_Usuario'], password = datos_usuario['Contraseña'])
            except KeyError as err:
                formulario_registro = IdentificacionForm()
                return render(request, "formulario.html",{ "título":"Autentificación" ,"form":formulario_registro})
            if usuario is not None:
                print("El usuario existe")
                login(request, usuario)
                return redirect('registro_usuarios:pagina_principal', referencia_instalacion = 0, username = usuario.get_username(), accion = "nada")


            else:
                print("El usuario no existe")

    else:
        formulario_registro = IdentificacionForm()
    
    return render(request, "formulario.html",{ "título":"Autentificación" ,"form":formulario_registro, "mensaje_boton":"Iniciar sesión"})

def pagina_principal(request, referencia_instalacion, username, accion):

    usuario = request.user
    lista_instalaciones_usuario = obtener_instalaciones_usuario(request.user)
    if referencia_instalacion > 0:
        instalación = get_object_or_404(Instalación, referencia = referencia_instalacion)
        if accion == "encender":
            instalación.encendida = True
            instalación.save()
        elif accion == "apagar":
            instalación.encendida = False
            instalación.save()
        elif accion == "borrar_instalacion":
            instalación.delete()
        
        else: pass
    if accion == "borrar_usuario":
            borrar_usuario(username)
        # Encender / Apagar Instalación
    if usuario.has_perms(["usuarios.edit_modelo"]):
        lista_instalaciones_usuario = Instalación.objects.all()
        #formulario_registro = RegistroUsuarioForm()
        #formulario_nueva_instalacion = AnyadirInstalacionForm()
        lista_usuarios = User.objects.all()
        return render(request, "pag_principalV2.html", {"lista_usuarios":lista_usuarios,"intalaciones_usuario":lista_instalaciones_usuario})
    #return render(request, "pagina_principal.html", {"nombre_usuario": usuario.username, "email_usuario": usuario.email, "intalaciones_usuario":lista_instalaciones_usuario})
    return render(request, "pagina_principal.html", {"nombre_usuario": usuario.username, "email_usuario": usuario.email, "intalaciones_usuario":lista_instalaciones_usuario})

def instalación_edit(request, referencia_instalacion):
    instalacion = Instalación.objects.get(referencia = referencia_instalacion)
    pk = instalacion.pk
    if  request.method == 'POST':
        formulario_instalacion = AnyadirInstalacionForm(request.POST)
        if formulario_instalacion.is_valid():
            datos_instalacion = formulario_instalacion.cleaned_data
            modificar_instalación(instalacion, datos_instalacion["Encargado"], datos_instalacion["Parque_Solar"], datos_instalacion["Referencia"], datos_instalacion["Potencia"])
            return redirect('registro_usuarios:pagina_principal', referencia_instalacion=0, username = "", accion = "nada")

    else:
        formulario_instalacion = AnyadirInstalacionForm(initial={'Encargado':instalacion.usuario_jefe.username, 'Parque_Solar':instalacion.parque_solar.nombre,
        'Referencia':instalacion.referencia, 'Potencia':instalacion.potencia})

    return render(request, "formulario.html",{"título":"Edición Instalación" ,"form":formulario_instalacion, "mensaje_boton":"Guardar cambios"})

def usuario_edit(request, username):
    usuario = User.objects.get(username = username)
    pk = usuario.pk
    if  request.method == 'POST':
        formulario = EditarUsuario(request.POST)
        if formulario.is_valid():
            datos = formulario.cleaned_data
            modificar_usuario(usuario, datos["username"], datos["email"], datos["password"])
            return redirect('registro_usuarios:pagina_principal', referencia_instalacion=0, username = "0", accion = "nada")

    else:
        formulario = EditarUsuario(initial={'username':usuario.username, 'email':usuario.email,
        'password':usuario.password})

    return render(request, "formulario.html",{"título":"Edición Usuario" ,"form":formulario, "mensaje_boton":"Guardar cambios"})