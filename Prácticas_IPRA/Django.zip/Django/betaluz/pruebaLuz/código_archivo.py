from io import open_code
import wget
import sys, csv
from os import remove
from .enviar_email import enviar_mensaje_correo
from .customExceptions import archivo_vacío_error


def descargar_archivo(fecha):

    '''Método que se encarga de crear la url del archivo a descargar,
    posteriormente descargarlo y guardarlo en el directorio "Descargas"'''

    try:
        fecha_url = fecha#.strftime("%Y%m%d")
        url = "https://www.omie.es/es/file-download?parents%5B0%5D=marginalpdbc&filename=marginalpdbc_{}.1".format(fecha_url)
        wget.download(url, '/home/usuario/Descargas/marginalpbdc_{}.1.txt'.format(fecha_url))
        #print("descargado")
        return ('/home/usuario/Descargas/marginalpbdc_{}.1.txt'.format(fecha_url))
    
    except Exception as e:
        sys.stderr.write('\nError al descargar archivo: {}\n'.format(e))

def procesar_archivo(fecha):

    direccion_archivo = descargar_archivo(fecha)

    try:
        with open(direccion_archivo) as archivo:
        
            lector_filas = csv.reader(archivo, delimiter=';')
            datos_global = []
            for fila in lector_filas:
                if fila and fila[0] != 'MARGINALPDBC' and fila[0] != '*':
                    fila[4] = float(fila[4])
                    fila[5] = float(fila[5])
                    datos_global += [fila]
            if len(datos_global) == 0:
                raise archivo_vacío_error
            return datos_global

    except FileNotFoundError:
        sys.stderr.write("\nArchivo no encontrado\n")
        raise
    except archivo_vacío_error:
        raise
    except:
        sys.stderr.write("\nError desconocido:\n")
        raise

def enviar_email_error():
    enviar_mensaje_correo('smtp.buzondecorreo.com', 465, 'ssl', 'jgomez@ipra.es', 'Bucs07ep','jgomez@ipra.es', 'jgomez@ipra.es',asunto='prueba', cuerpo='esto es una prueba')