

class excepcion_ejemplo(Exception):
    def __init__(self, mensaje = ""):
        self.mensaje = mensaje

    def __str__(self) -> str:
        return self.mensaje

class archivo_vacío_error(Exception):
    def __init__(self, mensaje = "El archivo está vacío"):
        self.mensaje = mensaje

    def __str__(self) -> str:
        return self.mensaje