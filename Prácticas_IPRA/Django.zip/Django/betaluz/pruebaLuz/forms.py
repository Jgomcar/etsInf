from django import forms

class formulario_archivo(forms.Form):

    fecha = forms.DateField()
    precio_consigna = forms.FloatField()