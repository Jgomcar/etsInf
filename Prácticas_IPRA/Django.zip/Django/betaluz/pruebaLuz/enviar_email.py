''' Envío de mensajes de email, a través de un servidor SMTP.
'''
import os
import smtplib
import ssl
import certifi
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


def crear_mensaje(cuenta_origen, cuenta_destino, cuenta_destino_copia=None,
                  cuenta_destino_copia_oculta=None, asunto=None, cuerpo=None,
                  archivo_adjunto=None):
    ''' Devuelve el contenido del mensaje en forma de objeto MIMEMultipart.
    Usa los mismos parámetros que la función enviar_mensaje_correo,
    excepto los referidos al servidor de correo.
    '''
    comienzo_mensaje = cuerpo.lstrip().lower()
    cuerpo_html = comienzo_mensaje[0:5] == '<html' or comienzo_mensaje[0:14] == '<!doctype html'
    if cuerpo_html:
        mensaje = MIMEMultipart('alternative')
    else:
        mensaje = MIMEMultipart()
    mensaje['From'] = cuenta_origen
    if isinstance(cuenta_destino, (list, tuple)):
        mensaje['To'] = ', '.join(cuenta_destino)
    else:
        mensaje['To'] = cuenta_destino
    if cuenta_destino_copia:
        if isinstance(cuenta_destino_copia, (list, tuple)):
            mensaje['Cc'] = ', '.join(cuenta_destino_copia)
        else:
            mensaje['Cc'] = cuenta_destino_copia
    if cuenta_destino_copia_oculta:
        if isinstance(cuenta_destino_copia_oculta, (list, tuple)):
            mensaje['Bcc'] = ', '.join(cuenta_destino_copia_oculta)
        else:
            mensaje['Bcc'] = cuenta_destino_copia_oculta
    mensaje['Subject'] = asunto

    if cuerpo_html:
        mensaje.attach(MIMEText(cuerpo, 'html'))
    else:
        mensaje.attach(MIMEText(cuerpo, 'plain'))

    if archivo_adjunto:
        # Si no existe el archivo adjunto indicado, no hacer nada más;
        # devolver error para indicar que no se ha enviado el mensaje
        if not os.path.isfile(archivo_adjunto):
            return (False, 'No se encuentra el archivo adjunto {}'.format(archivo_adjunto))
        adjunto = MIMEBase('application', 'octect-stream')
        with open(archivo_adjunto, 'rb') as archivo:
            adjunto.set_payload(archivo.read())
        encoders.encode_base64(adjunto)
        adjunto.add_header('Content-Disposition', 'attachment',
                           filename=os.path.basename(archivo_adjunto))
        mensaje.attach(adjunto)
    return mensaje

def enviar_mensaje_correo(servidor, puerto, encriptacion, usuario, password, cuenta_origen,
                          cuenta_destino, cuenta_destino_copia=None, cuenta_destino_copia_oculta=None,
                          asunto=None, cuerpo=None, archivo_adjunto=None):
    ''' Envia un mensaje de correo por SMTP.
    @param servidor: str: URL o IP del servidor de correo SMTP
    @param puerto: int: número del puerto SMTP
    @param encriptacion: str: 'tls', 'ssl', 'starttls' o None.
    @param usuario: str: nombre de usuario en el servidor SMTP.
    @param password: str: contraseña de usuario en el servidor SMTP.
    @param cuenta_origen: str: direción de email a usar como origen del mensaje.
    @param cuenta_destino: str/list: dirección o direcciones de email a usar como destino
        del mensaje. Si es una sola dirección, puede pasarse en forma de cadena; si son
        varias, pasar una lista de cadenas, una por dirección.
    @param cuenta_destino_copia: str/list, opcional: dirección o direcciones de email a
        usar como destino de copia del mensaje. Mismo formato que "cuenta_destino".
    @param cuenta_destino_copia_oculta: str/list, opcional: dirección o direcciones de
        email a usar como destino de copia oculta del mensaje. Mismo formato que
        "cuenta_destino".
    @param asunto: str: línea de texto con el asunto del mensaje.
    @param cuerpo: str: contenido del cuerpo del mensaje. Si comienza por <html o
        <!doctype html se asume que está en formato HTML; si no, en formato texto plano.
    @param archivo_adjunto: str, opcional: ruta de un archivo a adjuntar.
    @return: (bool,str) True si se envía el mensaje correctamente, False si no.
        En caso de error, el segundo parámetro contiene un mensaje describiendo el error.
    '''
    try:
        if encriptacion == 'ssl':
            # Evitar error "certificate verify failed: unable to get local issuer certificate"
            context = ssl.create_default_context(cafile=certifi.where())
            servidor_saliente = smtplib.SMTP_SSL(servidor, puerto, context=context)
        else:
            servidor_saliente = smtplib.SMTP(servidor, puerto)
        if encriptacion == 'tls' or encriptacion == 'starttls':
            servidor_saliente.starttls()
            # No es necesario, login() ya hace la llamada: servidor_saliente.ehlo()
    except Exception as e:
        return (False, 'Error al conectar al servidor de correo: {}'.format(e))

    try:
        servidor_saliente.login(usuario, password)
    except smtplib.SMTPAuthenticationError:
        return (False, 'Error al identificarse en el servidor de correo: ' \
            'no reconoce el usuario o la contraseña')
    except smtplib.SMTPHeloError:
        return (False, 'Error al identificarse en el servidor de correo: ' \
            'el servidor no responde')
    except smtplib.SMTPNotSupportedError:
        return (False, 'Error al identificarse en el servidor de correo: ' \
            'el servidor no admite identificación con usuario y contraseña')
    except smtplib.SMTPException:
        return (False, 'Error al identificarse en el servidor de correo: ' \
            'no se ha encontrado un método de autenticación adecuado')
    except Exception as e:
        return (False, 'Error al identificarse en el servidor de correo: {}'.format(e))

    try:
        mensaje = crear_mensaje(
            cuenta_origen,
            cuenta_destino,
            cuenta_destino_copia,
            cuenta_destino_copia_oculta,
            asunto,
            cuerpo,
            archivo_adjunto
        )
        servidor_saliente.send_message(mensaje)
    except smtplib.SMTPRecipientsRefused:
        return (False, 'Error al enviar el mensaje de correo: ' \
            'se ha rechazado la dirección de destino')
    except smtplib.SMTPHeloError:
        return (False, 'Error al enviar el mensaje de correo: ' \
            'el servidor no responde')
    except smtplib.SMTPSenderRefused:
        return (False, 'Error al enviar el mensaje de correo: ' \
            'se ha rechazado la dirección de origen')
    except smtplib.SMTPDataError:
        return (False, 'Error al enviar el mensaje de correo: ' \
            'el servidor ha respondido con un código de error inesperado')
    except Exception as e:
        return (False, 'Error al enviar el mensaje de correo: {}'.format(e))
    finally:
        servidor_saliente.quit()

    return (True, '')


