from typing import FrozenSet
from django.forms.utils import to_current_timezone
from django.shortcuts import redirect, render
from pruebaLuz.forms import formulario_archivo
from pruebaLuz.código_archivo import descargar_archivo, enviar_email_error, procesar_archivo
from django.http import HttpResponse
import wget
import sys
from .customExceptions import archivo_vacío_error

def contacto(request):

    if request.method == "POST":

        # Para almacenar la información que introdujo el usuario
        mi_formulario = formulario_archivo(request.POST)

        # Comprobar que el formulario es válido.
        if mi_formulario.is_valid():

            # La fecha se escribe en el formulario en formato yyyy-mm-dd
            información_formulario = mi_formulario.cleaned_data
            #fecha_archivo = información_formulario['fecha'].strftime("%Y%m%d")
            # Guardar datos de la sesión para usar en otras vistas.
            #request.session['fecha_archivo'] = fecha_archivo
            #request.session['precio_consigna'] = información_formulario['precio_consigna']
           
            # Cambios 19/7/2021
            # Transladar la parte de procesamiento del archivo a la llamada POST de esta vista
            fecha_archivo = información_formulario['fecha'].strftime("%Y%m%d")
            request.session['precio_consigna'] = información_formulario['precio_consigna']

            try:
                tabla_precios = procesar_archivo(fecha_archivo) 
                # Si no ocurre ningún error, cargar la vista de la tabla
                request.session['tabla_precios'] = tabla_precios
                # Redirige hacia otra vista
                return redirect('pruebaLuz:tabla')
            
            except archivo_vacío_error as error:
                mi_formulario = formulario_archivo()

                #enviar_email_error()

                return render(request, "formulario_archivo.html",{"form":mi_formulario, "error_descarga":True , "texto_error": str(error)})
            
            

    else:
        # Formulario vacío
        mi_formulario = formulario_archivo()
    # Cargar el formulario
    return render(request, "formulario_archivo.html",{"form":mi_formulario})

def tabla(request):

    # Obtener los datos guardados de la sesión
    tabla_precios = request.session['tabla_precios']
    precio_consigna = request.session['precio_consigna']
    
    return render(request, "tabla.html",{"tabla_precios":tabla_precios, "precio_consigna":precio_consigna})

    
       