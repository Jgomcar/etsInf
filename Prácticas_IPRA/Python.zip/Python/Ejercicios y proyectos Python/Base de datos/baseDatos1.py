import sqlite3
from sqlite3.dbapi2 import Error, OperationalError
import sys
import configparser

try:
    config = configparser.ConfigParser()
    config.read('configuracion.ini')
    #print(config.sections())
    data_base = config['BD']
    nombre_db = data_base['nombre']
    tabla_db = data_base['tabla']
    
    #con = sqlite3.connect('prueba.db')
    con = sqlite3.connect(nombre_db)
    cur = con.cursor()
    
    for columna in cur.execute('SELECT id, nombre, ip FROM ' +  str(tabla_db)):
        print(columna)
except OperationalError as e:
    sys.stderr.write('Error: {}\n'.format(e))
except KeyError:
    sys.stderr.write('''No se encuentra el archivo de inicialización\n
        o los campos no son los correctos''')
except Error as e:
    sys.stderr.write('Error: {}\n'.format(e))