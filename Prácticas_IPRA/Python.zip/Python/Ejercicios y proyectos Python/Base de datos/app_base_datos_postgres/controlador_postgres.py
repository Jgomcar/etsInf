import sys
from PySide2.QtSql import QSqlDatabase, QSqlTableModel
from PySide2 import QtWidgets
from PySide2.QtWidgets import *
from PySide2.QtCore import *
from main_window_postgres import Ui_MainWindow



class MainWindow(QMainWindow):

    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("Mini App BD postgres") 
        self.setFixedSize(805, 490) ### No redimensionable
        self.conectado = False ### Flag: NO conectado
        
        # Asignar los botones a sus funciones
        self.ui.btn_conectar.clicked.connect(self.conectar_bd)
        self.ui.btn_anyadir.clicked.connect(self.añadir_fila)
        self.ui.btn_borrar.clicked.connect(self.borrar_fila)
    
    @Slot()
    def añadir_fila(self):
        if self.conectado:
            row = self.model.rowCount()
            self.model.insertRow(row)
            index = self.model.index(row, 0)
            self.model.setData(index, row + 1)
            self.model.submitAll()
            index = self.model.index(row, 1)
            self.ui.tableView.setCurrentIndex(index)
            
    @Slot()   
    def borrar_fila(self):
        if self.conectado:
            index = self.ui.tableView.currentIndex()
            borrar = QtWidgets.QMessageBox.critical(self.parent(), "Fila borrada", "¿Seguro que desea borrar la fila?", 
            QtWidgets.QMessageBox.Yes, QtWidgets.QMessageBox.No)
            if borrar == QtWidgets.QMessageBox.Yes:
                self.model.removeRow(index.row())
                self.model.select()
                # self.model.submitAll() -> ¿No es necesario?
                self.actualizar_id()

    def actualizar_id(self):
        for fila in range(self.model.rowCount()):
            index = self.model.index(fila, 0)
            self.model.setData(index, int(fila+1))
        if not self.model.submitAll():
            # ha fallado al guardar
            exit(1)    

    @Slot()
    def conectar_bd(self):
        # Se supone que usando una llamada:
        #   db = QSqlDatabase("QSQLITE")
        # debería funcionar, pero aunque parece que se abre la conexión, luego no funciona
        # (no se puede acceder a las tablas)
        if self.ui.txt_hostname.text() == "" or self.ui.txt_password.text() == "" or self.ui.txt_username.text() == "" or self.ui.txt_databasename.text() == "":
            # Hay dos formas de hacerlo, con un código para el diálogo o con una sola línea con un constructor.
        #    self.dialogo_faltan_parametros()
           QMessageBox.critical(self, "Faltan datos","Debe especificar correctamente los datos para conectarse correctamente", QMessageBox.Ok, defaultButton = QMessageBox.Ok)
           return
        db = QSqlDatabase.addDatabase("QPSQL")
        db.setHostName(self.ui.txt_hostname.text())
        db.setDatabaseName(self.ui.txt_databasename.text())
        db.setUserName(self.ui.txt_username.text())
        db.setPassword(self.ui.txt_password.text())
        if not db.open():
            # No se ha podido abrir la base de datos postgres
            QMessageBox.critical(self, "Fallo en apertura","Fallo al abrir la base de datos", QMessageBox.Ok, defaultButton = QMessageBox.Ok)
            print('Abriendo base de datos: {}; nativeErrorCode={}'.format(db.lastError().text(), db.lastError().nativeErrorCode()))
            return
        print('Abriendo base de datos: {}; nativeErrorCode={}'.format(db.lastError().text(), db.lastError().nativeErrorCode()))
        self.model = QSqlTableModel()
        self.model.setTable(self.ui.txt_tabla_de_datos.text())
        if self.model.lastError().text() != "":
            # No se ha abierto correctamente la tabla
            print("Error: {}".format(self.model.lastError().text()))
            return
        self.model.select()
        self.model.setEditStrategy(QSqlTableModel.OnFieldChange)

        if self.model.lastError().text() != "":
            self.dialogo_fallo_tabla(self.model.lastError().text())
            return
    
        self.ui.tableView.setModel(self.model)
        self.conectado = True

if __name__ == "__main__":
    app = QApplication(sys.argv)

    window = MainWindow()
    window.show()
    sys.exit(app.exec_())