import pywhatkit as pw

pw.sendwhatmsg("+34000000000", "Hello, World", 14,18)