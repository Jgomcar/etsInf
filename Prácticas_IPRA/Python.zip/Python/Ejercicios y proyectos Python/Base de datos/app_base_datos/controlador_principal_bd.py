import sys
from PySide2.QtSql import QSqlDatabase, QSqlTableModel
from PySide2 import QtWidgets
from PySide2.QtWidgets import *
from PySide2.QtCore import *
from ventana_principal import Ui_MainWindow
import os

class MainWindow(QMainWindow):

    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("Mini App BD") 
        self.setFixedSize(805, 490) ### No redimensionable
        self.conectado = False ### Flag: NO conectado
        
        # Asignar los botones a sus funciones
        self.ui.btn_buscar.clicked.connect(self.obtener_ruta_basedatos)
        self.ui.btn_conectar.clicked.connect(self.conectar_bd)
        self.ui.btn_anyadir.clicked.connect(self.añadir_fila)
        self.ui.btn_borrar.clicked.connect(self.borrar_fila)
    
    @Slot()
    def añadir_fila(self):
        if self.conectado:
            row = self.model.rowCount()
            self.model.insertRow(row)
            index = self.model.index(row, 0)
            self.model.setData(index, row + 1)
            self.model.submitAll()
            index = self.model.index(row, 1)
            self.ui.tableView.setCurrentIndex(index)
            
    @Slot()   
    def borrar_fila(self):
        if self.conectado:
            index = self.ui.tableView.currentIndex()
            borrar = QtWidgets.QMessageBox.critical(self.parent(), "Fila borrada", "¿Seguro que desea borrar la fila?", 
            QtWidgets.QMessageBox.Yes, QtWidgets.QMessageBox.No)
            if borrar == QtWidgets.QMessageBox.Yes:
                self.model.removeRow(index.row())
                self.model.select()
                # self.model.submitAll() -> ¿No es necesario?
                self.actualizar_id()

    def actualizar_id(self):
        for fila in range(self.model.rowCount()):
            index = self.model.index(fila, 0)
            self.model.setData(index, int(fila+1))
        if not self.model.submitAll():
            # ha fallado al guardar
            exit(1)    

    @Slot()
    def conectar_bd(self):
        # Se supone que usando una llamada:
        #   db = QSqlDatabase("QSQLITE")
        # debería funcionar, pero aunque parece que se abre la conexión, luego no funciona
        # (no se puede acceder a las tablas)
        if self.ui.txt_base_de_datos == "" or self.ui.txt_tabla_de_datos.text() == "":
            # Hay dos formas de hacerlo, con un código para el diálogo o con una sola línea con un constructor.
        #    self.dialogo_faltan_parametros()
           QMessageBox.critical(self, "Faltan datos","Debe especificar correctamente la base de datos y la tabla donde se encuentran", QMessageBox.Ok, defaultButton = QMessageBox.Ok)
           return
        if not os.path.exists(self.nombre_basedatos):
            # No existe el archivo
            return
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName(self.nombre_basedatos)
        if not db.open():
            # No se ha podido abrir el archivo
            return
        # print('Abriendo base de datos: {}; nativeErrorCode={}'.format(db.lastError().text(), db.lastError().nativeErrorCode()))
        self.model = QSqlTableModel()
        self.model.setTable(self.ui.txt_tabla_de_datos.text())
        if self.model.lastError().text() != "":
            # No se ha abierto correctamente la tabla
            print("Error: {}".format(self.model.lastError().text()))
            return
        self.model.select()
        self.model.setEditStrategy(QSqlTableModel.OnFieldChange)

        if self.model.lastError().text() != "":
            self.dialogo_fallo_tabla(self.model.lastError().text())
            return
    
        self.ui.tableView.setModel(self.model)
        self.conectado = True
    
    @Slot()
    def obtener_ruta_basedatos(self):
        lista_basedatos= QFileDialog.getOpenFileName(self, "Abre la base de datos", "C://")
        # print(lista_basedatos)
        # filename = QFileInfo(file_name[0]).fileName()
        # print(filename)
        self.ui.txt_base_de_datos.setText(lista_basedatos[0])
        self.nombre_basedatos = lista_basedatos[0]

    def dialogo_faltan_parametros(self):
        '''Cuadro de diálogo que se muestra al faltar parématros
        sobre la base de datos o la tabla de datos.'''
        dlg = QMessageBox(self)
        dlg.setWindowTitle("Aviso de Error")
        dlg.setText("""
        Debe especificar correctamente
        la base de datos y la tabla donde se encuentran""")
        dlg.setIcon(QMessageBox.Critical)
        dlg.exec_()

    def dialogo_fallo_tabla(self, texto_error):
        '''Cuadro de diálogo que se muestra al indicar una 
        tabla que no existe.'''
        dlg = QMessageBox(self)
        dlg.setWindowTitle("Aviso de Error")
        dlg.setText("""
        Debe especificar correctamente
        la tabla donde se encuentran los datos.\n {}""".format(texto_error))
        dlg.setIcon(QMessageBox.Critical)
        dlg.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)

    window = MainWindow()
    window.show()
    sys.exit(app.exec_())