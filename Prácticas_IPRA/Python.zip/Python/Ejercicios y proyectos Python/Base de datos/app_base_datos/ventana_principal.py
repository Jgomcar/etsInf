# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'base_de_datos_1eNolof.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(810, 489)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(20, 20, 211, 21))
        font = QFont()
        font.setPointSize(12)
        self.label.setFont(font)
        self.label_2 = QLabel(self.centralwidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(20, 50, 241, 21))
        self.label_2.setFont(font)
        self.txt_base_de_datos = QLineEdit(self.centralwidget)
        self.txt_base_de_datos.setObjectName(u"txt_base_de_datos")
        self.txt_base_de_datos.setGeometry(QRect(270, 20, 291, 21))
        font1 = QFont()
        font1.setPointSize(10)
        self.txt_base_de_datos.setFont(font1)
        self.txt_tabla_de_datos = QLineEdit(self.centralwidget)
        self.txt_tabla_de_datos.setObjectName(u"txt_tabla_de_datos")
        self.txt_tabla_de_datos.setGeometry(QRect(270, 50, 291, 20))
        self.txt_tabla_de_datos.setFont(font1)
        self.line = QFrame(self.centralwidget)
        self.line.setObjectName(u"line")
        self.line.setGeometry(QRect(10, 80, 781, 20))
        self.line.setFrameShape(QFrame.HLine)
        self.line.setFrameShadow(QFrame.Sunken)
        self.btn_buscar = QPushButton(self.centralwidget)
        self.btn_buscar.setObjectName(u"btn_buscar")
        self.btn_buscar.setGeometry(QRect(640, 10, 111, 31))
        font2 = QFont()
        font2.setPointSize(17)
        self.btn_buscar.setFont(font2)
        self.tableView = QTableView(self.centralwidget)
        self.tableView.setObjectName(u"tableView")
        self.tableView.setGeometry(QRect(20, 110, 521, 301))
        self.tableView.setDragEnabled(False)
        self.btn_anyadir = QPushButton(self.centralwidget)
        self.btn_anyadir.setObjectName(u"btn_anyadir")
        self.btn_anyadir.setGeometry(QRect(580, 160, 181, 41))
        font3 = QFont()
        font3.setPointSize(21)
        self.btn_anyadir.setFont(font3)
        self.btn_borrar = QPushButton(self.centralwidget)
        self.btn_borrar.setObjectName(u"btn_borrar")
        self.btn_borrar.setGeometry(QRect(580, 300, 181, 41))
        self.btn_borrar.setFont(font3)
        self.btn_conectar = QPushButton(self.centralwidget)
        self.btn_conectar.setObjectName(u"btn_conectar")
        self.btn_conectar.setGeometry(QRect(640, 50, 111, 31))
        self.btn_conectar.setFont(font2)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 810, 21))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Nombre de la base de datos:", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Nombre de la tabla para analizar:", None))
        self.txt_base_de_datos.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Ejemplo: base_de_datos.db", None))
        self.txt_tabla_de_datos.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Ejemplo: dispositivos", None))
        self.btn_buscar.setText(QCoreApplication.translate("MainWindow", u"Buscar", None))
        self.btn_anyadir.setText(QCoreApplication.translate("MainWindow", u"A\u00f1adir fila", None))
        self.btn_borrar.setText(QCoreApplication.translate("MainWindow", u"Borrar fila", None))
        self.btn_conectar.setText(QCoreApplication.translate("MainWindow", u"Conectar", None))
    # retranslateUi
