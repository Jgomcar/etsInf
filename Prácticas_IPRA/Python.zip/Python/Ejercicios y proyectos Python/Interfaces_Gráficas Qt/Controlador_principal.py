import sys
from PySide2 import QtCore
from PySide2.QtCore import Qt
from PySide2 import QtWidgets
from PySide2.QtWidgets import QAction, QApplication, QCheckBox, QComboBox, QDialog, QLabel, QLineEdit, QMainWindow, QMenu, QMessageBox, QPushButton, QVBoxLayout, QWidget
from PySide2.QtCore import QFile, QSize
from PySide2.QtCore import Slot
#from ui_mainwindow import Ui_MainWindow
#from clase_ventana_principal import Ui_MainWindow
from ui_mainwindow import Ui_MainWindow
from dialogo_custom import CustomDialog
from random import randint

class MainWindow(QMainWindow):
    
    @Slot()
    def btn_clicked(self):
        print("Hola mundo!")
        texto_nuevo = 'Hola Mundo!'
        self.ui.label_2.setText(texto_nuevo)
        self.setWindowTitle("nuevo título")
    
    def __init__(self):
        # super(MainWindow, self).__init__()
        # self.ui = Ui_MainWindow()
        # self.ui.setupUi(self)
        # button1 = self.ui.btn_holaMundo
        # button1.clicked.connect(self.btn_clicked)
        #texto = self.ui.label.text()
        #texto_nuevo = 'prueba'
        #self.ui.label.setText(texto_nuevo)

        super().__init__()
        self.setWindowTitle("Mi App")

        #self.setFixedSize(QSize(400,300))
        self.setMaximumSize(QSize(1000,1000))
        self.setMinimumSize(QSize(400,300))

        # Label
        #widget = QLabel("Hello")
        #font = widget.font()
        #font.setPointSize(30)
        #widget.setFont(font)
        #self.setCentralWidget(widget)
        # widget.setAligment(Qt.AligHCenter | Qt.AligVCenter)

        # CheckBox
        # widget = QCheckBox("This is a checkbox")
        # widget.setCheckState(Qt.Checked)
        # widget.stateChanged.connect(self.show_state)
        # self.setCentralWidget(widget)

        # ComboBox
        # widget = QComboBox()
        # widget.addItems(["One", "Two", "Three"])
        # widget.currentIndexChanged.connect(self.index_changed)
        # widget.currentTextChanged.connect(self.text_changed)
        # self.setCentralWidget(widget)

        # QLineEdit
        # widget = QLineEdit()
        # widget.setMaxLength(10)
        # widget.setPlaceholderText("Enter your text")

        # widget.returnPressed.connect(self.return_pressed)
        # widget.selectionChanged.connect(self.selection_changed)
        # widget.textChanged.connect(self.text_changed)
        # widget.textEdited.connect(self.text_edited)
        # widget.setInputMask('000.000.000.000;_')
        # self.setCentralWidget(widget)

        # Cuadros de Diálogo
        self.w = AnotherWindow()
        self.button = QPushButton("Push for Window")
        # button.clicked.connect(self.button_clicked)
        # button.clicked.connect(self.show_new_window)
        
        # Pasar información a otra pestaña
        # self.button.clicked.connect(self.toggle_window)

        # self.input = QLineEdit()
        # self.input.textChanged.connect(self.w.label.setText)
        # layout = QVBoxLayout()
        # layout.addWidget(self.button)
        # layout.addWidget(self.input)
        # container = QWidget()
        # container.setLayout(layout)

        # self.setCentralWidget(container)

        # Mouse Events
        self.label = QLabel("Click this window")
        self.setCentralWidget(self.label)

# CONTEXT MENU
    def contextMenuEvent(self, e):
        context = QMenu(self)
        context.addAction(QAction("test 1",self))
        context.addAction(QAction("test 2",self))
        context.addAction(QAction("test 3",self))
        context.exec_(e.globalPos())

    def mouseMoveEvent(self, e):
        self.label.setText("mouseMoveEvent")
    def mousePressEvent(self, e):
        self.label.setText("mousePressEvent")
    def mouseReleaseEvent(self, e):
        self.label.setText("mouseReleaseEvent")
    def mouseDoubleClickEvent(self, e):
        self.label.setText("mouseDoubleClickEvent")

    def toggle_window(self, checked):
        if self.w.isVisible():
            self.w.hide()
        else:
            self.w.show()

    def show_new_window(self, checked):
        if self.w is None:
            self.w = AnotherWindow()
            self.w.show()
        else:
            self.w.close()
            self.w = None # Discard reference, close window

    def button_clicked(self, s):
        print("click", s)
        # dlg = QDialog(self)
        # dlg.setWindowTitle("?")
        # dlg.exec_()

        #le pasamos self como padre
        # dlg = CustomDialog(self)
        # if dlg.exec_():
        #     print ("Success!")
        # else:
        #     print("Cancel!")

        # Cuadros de Mensaje
        # dlg = QMessageBox(self)
        # dlg.setWindowTitle("I have a dream")
        # dlg.setText("This is a simple human")
        # button = dlg.exec_()
        # if button == QMessageBox.Ok:
        #     print("OK!")

        # Ahora con dos botones:
        # dlg = QMessageBox(self)
        # dlg.setWindowTitle("I'm only human")
        # dlg.setText("This is a question dialog")
        # dlg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        # dlg.setIcon(QMessageBox.Question)
        # button = dlg.exec_()

        # Otra forma de hacerlo
        # button = QMessageBox.question(self, "Question dialog", "The longer message")
        
        # if button == QMessageBox.Yes:
        #     print("Yes")
        # else:
        #     print("No")
        
        # Dialogo crítico
        # button = QMessageBox.critical(self,"Oh no!","Something went very wrong",
        #     buttons = QMessageBox.Discard | QMessageBox.NoToAll | QMessageBox.Ignore,
        #     defaultButton = QMessageBox.Discard,
        # )
        # if button == QMessageBox.Discard:
        #     print("Discard!")
        # elif button == QMessageBox.NoToAll:
        #     print("No to all!")
        # else: 
        #     print("Ignore!")


    def return_pressed(self):
        print("Return pressed!")
        self.centralWidget().setText("BOOM!")
    def selection_changed(self):
        print ("Selection changed")
        print(self.centralWidget().selectedText())
    def text_edited(self, s):
        print("Text edited...")
        print(s)


    def index_changed(self, i):
        print(i)
    def text_changed(self, s):
        print("Text changed...")
        print(s)

    def show_state(self, s):
        print (s == Qt.Checked)
        print(s)

class AnotherWindow(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        self.label = QLabel("Another Window")
        layout.addWidget(self.label)
        self.setLayout(layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)

    window = MainWindow()
    #button.clicked.connect(hola_mundo)
    window.show()

    sys.exit(app.exec_())