# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'designercylcUP.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        self.actionabrir = QAction(MainWindow)
        self.actionabrir.setObjectName(u"actionabrir")
        self.actionguardar = QAction(MainWindow)
        self.actionguardar.setObjectName(u"actionguardar")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        self.label.setEnabled(True)
        self.label.setGeometry(QRect(626, 12, 141, 31))
        self.btn_holaMundo = QPushButton(self.centralwidget)
        self.btn_holaMundo.setObjectName(u"btn_holaMundo")
        self.btn_holaMundo.setGeometry(QRect(320, 160, 141, 41))
        font = QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.btn_holaMundo.setFont(font)
        self.label_2 = QLabel(self.centralwidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setEnabled(True)
        self.label_2.setGeometry(QRect(310, 200, 161, 81))
        font1 = QFont()
        font1.setPointSize(20)
        self.label_2.setFont(font1)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 21))
        self.menuMen_archivo = QMenu(self.menubar)
        self.menuMen_archivo.setObjectName(u"menuMen_archivo")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.menubar.addAction(self.menuMen_archivo.menuAction())
        self.menuMen_archivo.addAction(self.actionabrir)
        self.menuMen_archivo.addAction(self.actionguardar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionabrir.setText(QCoreApplication.translate("MainWindow", u"abrir", None))
        self.actionguardar.setText(QCoreApplication.translate("MainWindow", u"guardar", None))
        self.label.setText("")
        self.btn_holaMundo.setText(QCoreApplication.translate("MainWindow", u"Pulsar Bot\u00f3n", None))
        self.label_2.setText("")
        self.menuMen_archivo.setTitle(QCoreApplication.translate("MainWindow", u"Men\u00fa archivo", None))
    # retranslateUi
