import sqlite3
import configparser
import sys
from sqlite3.dbapi2 import DataError, DatabaseError, Error, OperationalError
from datetime import datetime

def añadir_fila(conexion, factores):
    '''Método que añade una fila a la base de datos'''
    cursor_bd = conexion.cursor()
    # Insertar en una tabla
    try:
        cursor_bd.execute('INSERT INTO factores(fecha_hora, temperatura, humedad, CO2) VALUES (?, ?, ?, ?)', factores)
        conexion.commit()
    except SyntaxError as e:
        sys.stderr.write('''
            Instrucciones erróneas, revisar código\n\n''')
        sys.stderr.write('Error: {}\n'.format(e))
    #except Exception as e:
     #   sys.stderr.write('Error: {}\n'.format(e))

def conectarse_BD():
    '''Método que decuelve una conexión con la base de datos'''
    config = configparser.ConfigParser()
    config.read('factores.ini')
    base_datos = config['BD']
    nombre_bd = base_datos['nombre']

    conexion = sqlite3.connect(nombre_bd)
    return conexion
    
def escribir_contenido(conexion):
    '''Método que imprime por pantalla el contenido de la base de datos'''
    config = configparser.ConfigParser()
    config.read('factores.ini')
    tabla_bd = config['BD']['tabla']
    cursor_bd = conexion.cursor()
    for columna in cursor_bd.execute('SELECT fecha_hora, temperatura, humedad, CO2 FROM ' +  str(tabla_bd)):
            print(columna) 

if __name__ == '__main__':
    if len(sys.argv) < 4:
        #Comprobamos que ha introducido el número correcto de argumentos
        sys.stderr.write('Not enough arguments')
    else:
        try:
            #Obtenemos conexión con la base de datos
            conexion = conectarse_BD()

        except DatabaseError as e:
            sys.stderr.write('''
            Ha ocurrido un error con la base de datos\n''')
            sys.stderr.write('Error: {}\n'.format(e))
            exit(1)
        except KeyError as e:
            sys.stderr.write('''
            Fichero de acceso a base de datos o parámetros erróneos\n\n''')
            sys.stderr.write('Error: {}\n'.format(e))
            exit(1)

        now = datetime.now()
        fecha_hora = '{}/{}/{} {}:{}'.format(now.day, now.month, now.year, now.hour, now. minute)

        try:
            #creamos el parámetro a partir de los argumentos de entrada, para añadir a la base de datos
            factores = (fecha_hora, float(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]) )
            añadir_fila(conexion,factores)
            escribir_contenido(conexion)
        except DatabaseError as e:
            sys.stderr.write('''
            Ha ocurrido un error con la base de datos\n''')
            sys.stderr.write('Error: {}\n'.format(e))
        except ValueError as e:
            sys.stderr.write('''
            Valores introducidos erróneos
            Introduzca valores correctos para temperatura, humedad y CO2\n\n''')
            sys.stderr.write('Error: {}\n'.format(e))
        except Exception as e:
            sys.stderr.write('Error: {}\n'.format(e))    
        finally:
            conexion.close()

        
        

        