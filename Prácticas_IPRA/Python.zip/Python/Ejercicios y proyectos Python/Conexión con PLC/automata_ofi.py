from cliente_plc import ClientePLCSiemens
import sys
from cliente_plc import TipoDatos

if __name__ == '__main__':
    #192.168.0.245
    direccion_ip = '192.168.0.245'
    direccion_dato = 48
    cliente = ClientePLCSiemens()
    cliente.conectar(direccion_ip)
    cliente.escribir_valor(32,direccion_dato, TipoDatos.real, 2)
    dato = cliente.leer_valor(direccion_dato, TipoDatos.real, 2)
    print (dato)