from cliente_plc import  ClientePLCModbus
import sys
from cliente_plc import TipoDatos

if __name__ == '__main__':
    #192.168.0.245
    #127.0.0.1 dirección local
    direccion_ip = '127.0.0.1'
    direccion_dato = 0
    cliente = ClientePLCModbus(direccion_ip)
    cliente.conectar()
    dato = cliente.leer_valor(direccion_dato, TipoDatos.entero)
    print (dato)