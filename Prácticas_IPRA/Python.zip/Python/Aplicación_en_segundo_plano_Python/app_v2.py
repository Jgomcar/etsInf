import wget, sys, time, logging, os
from datetime import datetime, timedelta
from configparser import ConfigParser
import configparser
import inspect

import win32serviceutil
import win32event
import win32service
import servicemanager
import socket
from SMWinservice import SMWinservice



    

def pausa_corta_proceso( direccion_destino, pausa_corta):
        if  os.stat(direccion_destino).st_size == 0:
            os.remove(direccion_destino)
        logging.debug("A dormir...corto")
        time.sleep(pausa_corta)
        logging.debug("Me despierto...corto")

def pausa_larga_proceso( pausa_larga):
        logging.debug("A dormir...largo")
        time.sleep(pausa_larga)
        logging.debug("Vuelvo a despertar..largo")

def descargar_archivo( url_fuente, direccion_destino):

        '''Método que se encarga de crear la url del archivo a descargar,
        posteriormente descargarlo y guardarlo en el directorio "Descargas"'''

        try:
            wget.download(url_fuente, direccion_destino)
            logging.info("Archivo descargado")
        
        except Exception as e:
            sys.stderr.write('\nError al descargar archivo: {}\n'.format(e))
            logging.error("Error al descargar el archivo")
            raise e

def comprobar_archivo( direccion_destino):
        return os.path.isfile(direccion_destino) and not os.stat(direccion_destino).st_size == 0
        # if os.path.isfile(direccion_destino):
        #     return True

        # if os.stat(direccion_destino).st_size == 0:
        #     os.remove(direccion_destino)
        #     return False
        # else:
        #     return True

def actualizar_datos(url_fuente, direccion_destino):
        fecha=datetime.now().strftime("%Y%m%d")
        # fecha=datetime.now() + timedelta(days=2)
        # fecha=fecha.strftime("%Y%m%d")
        url_fuente += "{}.1".format(fecha)
        direccion_destino += "{}.1.txt".format(fecha)
        logging.info("Actualizando datos")
        return url_fuente, direccion_destino


if __name__ == "__main__":
    niveles = {'DEBUG': logging.DEBUG, 'INFO': logging.INFO, 'WARNING' : logging.WARNING, 'ERROR' : logging.ERROR,'CRITICAL':logging.CRITICAL}
   
        # Para obtener la ruta del archivo que se está ejecutando y poder buscar ahí el archivo INI
    _ruta_ejecutable = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        #Interpolation = None para que no interprete los caracteres %
    try:
            config = configparser.ConfigParser(interpolation=None)
            config.read(os.path.join(_ruta_ejecutable,'app_segundo_plano.ini'))
            Datos = config['Datos']
            url = Datos['url_fuente']
            direccion_dst = Datos['direccion_destino']
            pausa_corta = Datos['pausa_corta']
            pausa_larga = Datos['pausa_larga']
            logging_level = Datos['logging_level']

    except configparser.NoSectionError as err:
            sys.stderr.write("Error: El archivo especificado INI no ha sido encontrado",err)
            exit(1)
    except configparser.NoOptionError as err:
            sys.stderr.write("Error: Opción especificada no encontrada en el archivo INI especificado",err)
            exit(1)
    except configparser.InterpolationError as err:
            sys.stderr.write("Error: Error al realizar la interpolación entre cadenas",err)
            exit(1)
    except configparser.ParsingError as err:
            sys.stderr.write("Error: Error al intentar analizar un archivo",err)
            exit(1)   
    except KeyError as err:
            sys.stderr.write("Error: Parámetros de acceso al archivo erróneos")
            exit(1)
        
    try:
            logging.basicConfig(filename='C:/Users/Usuario/Desktop/Python/APP_Sec/debug.log', encoding='utf-8', level = niveles[logging_level])
            # Errores al utilizar el carácter '\'. otra forma de poner la ruta sería:
            # "r'C:\Users\Usuario\Desktop\Python\APP_Sec\debug.log"
    except KeyError as err:
            sys.stderr.write("Error: nivel de depuración erróneo. Pruebe con 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'.")
            exit(1)


    logging.debug("Arrancando el programa en segundo plano")

    try:
            pausa_corta = int(pausa_corta)
            pausa_larga = int(pausa_larga)
    except ValueError as err:
            sys.stderr.write("Error: los valores '{}' o/y '{}' no son valores enteros".format(pausa_corta, pausa_larga))
            exit(1)

    while True:

            url_fuente, direccion_destino = actualizar_datos(url, direccion_dst)
            logging.info("Intento la descarga")
            
            if not comprobar_archivo(direccion_destino):
                descargar_archivo(url_fuente, direccion_destino)
                pausa_corta_proceso(direccion_destino, pausa_corta)
            else:
                pausa_larga_proceso(pausa_larga)
   