# Cuando utilizas Python como calculadora el
# simbolo '_' se utiliza para referirse a la última expresión calculada
s = 'First line. \nSecond line.'
#si se printea hay salto de linea
print (s)
#pero y si queremos poner \n?
# agregamos r antes de la 1ª comilla para especificar 'sin formato'
print ('C:\some\name')
print (r'C:\some\name')

# Las cadenas se pueden concatenar(+) y repetir (*)
print ('un' * 3 + ' diez')
# Dos cadenas una al lado de la otra se concatenan
print('Py' 'thon')
